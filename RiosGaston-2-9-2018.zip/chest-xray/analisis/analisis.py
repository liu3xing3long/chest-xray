
# coding: utf-8

# In[65]:


import os
from skimage import io, color, exposure
from skimage.transform import resize
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')


# In[66]:


test_normal_dir = "../input/test/NORMAL"
test_pneumonia_dir = "../input/test/PNEUMONIA"
train_normal_dir = "../input/train/NORMAL"
train_pneumonia_dir = "../input/train/PNEUMONIA"
full_url = np.vectorize(lambda url,prev_url: prev_url+"/"+url)
test_normal_data = pd.DataFrame(full_url(np.array(os.listdir(test_normal_dir)),test_normal_dir), columns=["image_dir"])
test_pneumonia_data = pd.DataFrame(full_url(np.array(os.listdir(test_pneumonia_dir)),test_pneumonia_dir), columns=["image_dir"])
train_normal_data = pd.DataFrame(full_url(np.array(os.listdir(train_normal_dir)),train_normal_dir), columns=["image_dir"])
train_pneumonia_data = pd.DataFrame(full_url(np.array(os.listdir(train_pneumonia_dir)),train_pneumonia_dir), columns=["image_dir"])
test_normal_data["class"] = "NORMAL"
test_pneumonia_data["class"] = "PNEUMONIA"
train_normal_data["class"] = "NORMAL"
train_pneumonia_data["class"] = "PNEUMONIA"
test_data = test_normal_data.append(test_pneumonia_data)
train_data = train_normal_data.append(train_pneumonia_data)


# In[3]:


print("Training data size",train_data.shape)
print("Test data size",test_data.shape)


# In[4]:


# train clases sizes
pd.DataFrame(train_data['class'].value_counts())


# In[5]:


# test clases sizes
pd.DataFrame(test_data['class'].value_counts())


# In[7]:


w=10
h=10
fig=plt.figure(figsize=(8, 8))
columns = 4
rows = 5
sample = train_data.sample(21)["image_dir"].values
for i in range(1, columns*rows +1):
    img = io.imread(sample[i])
    fig.add_subplot(rows, columns, i)
    plt.imshow(img)
plt.show()


# In[66]:


w=10
h=10
fig=plt.figure(figsize=(8, 8))
columns = 4
rows = 5
sample = train_data[train_data["class"] == "PNEUMONIA"].sample(20)["image_dir"].values
for i in range(1, columns*rows +1):
    img = io.imread(sample[i-1])
    fig.add_subplot(rows, columns, i)
    plt.imshow(img)
plt.show()


# In[68]:


train_normal_dir = "../input/preprocessed-normalized/train/NORMAL"
train_pneumonia_dir = "../input/preprocessed-normalized/train/PNEUMONIA"
full_url = np.vectorize(lambda url,prev_url: prev_url+"/"+url)
train_normal_data = pd.DataFrame(full_url(np.array(os.listdir(train_normal_dir)),train_normal_dir), columns=["image_dir"])
train_pneumonia_data = pd.DataFrame(full_url(np.array(os.listdir(train_pneumonia_dir)),train_pneumonia_dir), columns=["image_dir"])
train_normal_data["class"] = "NORMAL"
train_pneumonia_data["class"] = "PNEUMONIA"
train_data_normalized = train_normal_data.append(train_pneumonia_data)

# preprocessed previsualization

w=10
h=10
fig=plt.figure(figsize=(8, 8))
columns = 4
rows = 5
sample = train_data_normalized.sample(21)["image_dir"].values
for i in range(1, columns*rows +1):
    image = io.imread(sample[i])
    fig.add_subplot(rows, columns, i)
    plt.imshow(image)
plt.show()


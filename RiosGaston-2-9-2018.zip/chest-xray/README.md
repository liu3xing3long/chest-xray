# chest-xray
chest-xray pneumonia prediction using cnn

Download kaggle api and tensorflow

https://github.com/Kaggle/kaggle-api
https://www.tensorflow.org/install/

Download the dataset and place it in the input folder: 

```
kaggle datasets download -d paultimothymooney/chest-xray-pneumonia
```

Run data-preprocesing/dataPreprocessing.py

Run data-preprocesing/normalization.py

After that you can run nn/CNN.py to start running the network training.

You can use tensorboard --logdir=./logs/train to view train logs in tensorboard and tensorboard --logdir=./logs/test to view test logs

GitHub: https://github.com/okason97/chest-xray

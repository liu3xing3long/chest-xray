
# coding: utf-8

# In[1]:


import os
from multiprocessing import Pool
import numpy as np # linear algebra
import pandas as pd

from skimage import io
from sklearn import preprocessing
from sklearn.externals import joblib


# In[2]:


scaler_filename = "../models/images_StandardScaler.save"
normalized_dir = "../input/preprocessed-normalized/"
shape = 256


# In[3]:


def normalize_image(image_dir):
    image = np.array(io.imread(image_dir))
    out_dir = normalized_dir + "/".join(image_dir.split("/")[-3:])
                
    # Load scaler
    scaler = joblib.load(scaler_filename)
   
    old_image=image
    # standarization or normalization
    image = image.reshape(1,-1)

    image = scaler.transform(image)
    for row in image:
        row[row>1] = 1
        row[row<-1] = -1
    image = image.reshape(shape,shape)

    io.imsave(out_dir,image)    
    print("normalized image saved in: "+out_dir)


# In[4]:


processes = 4

test_normal_dir = "../input/preprocessed/test/NORMAL"
test_pneumonia_dir = "../input/preprocessed/test/PNEUMONIA"
train_normal_dir = "../input/preprocessed/train/NORMAL"
train_pneumonia_dir = "../input/preprocessed/train/PNEUMONIA"
val_normal_dir = "../input/preprocessed/val/NORMAL"
val_pneumonia_dir = "../input/preprocessed/val/PNEUMONIA"
full_url = np.vectorize(lambda url,prev_url: prev_url+"/"+url)
test_normal_data = pd.DataFrame(full_url(np.array(os.listdir(test_normal_dir)),test_normal_dir), columns=["image_dir"])
test_pneumonia_data = pd.DataFrame(full_url(np.array(os.listdir(test_pneumonia_dir)),test_pneumonia_dir), columns=["image_dir"])
train_normal_data = pd.DataFrame(full_url(np.array(os.listdir(train_normal_dir)),train_normal_dir), columns=["image_dir"])
train_pneumonia_data = pd.DataFrame(full_url(np.array(os.listdir(train_pneumonia_dir)),train_pneumonia_dir), columns=["image_dir"])
val_normal_data = pd.DataFrame(full_url(np.array(os.listdir(val_normal_dir)),val_normal_dir), columns=["image_dir"])
val_pneumonia_data = pd.DataFrame(full_url(np.array(os.listdir(val_pneumonia_dir)),val_pneumonia_dir), columns=["image_dir"])
test_data = test_normal_data.append(test_pneumonia_data)
train_data = train_normal_data.append(train_pneumonia_data)
val_data = val_normal_data.append(val_pneumonia_data)

os.makedirs(normalized_dir, exist_ok=True)    
os.makedirs(normalized_dir + "test", exist_ok=True)    
os.makedirs(normalized_dir + "train", exist_ok=True)    
os.makedirs(normalized_dir + "val", exist_ok=True)    
os.makedirs(normalized_dir + "test/NORMAL", exist_ok=True)    
os.makedirs(normalized_dir + "test/PNEUMONIA", exist_ok=True)
os.makedirs(normalized_dir + "train/NORMAL", exist_ok=True)
os.makedirs(normalized_dir + "train/PNEUMONIA", exist_ok=True)
os.makedirs(normalized_dir + "val/NORMAL", exist_ok=True)
os.makedirs(normalized_dir + "val/PNEUMONIA", exist_ok=True)
    
pool = Pool(processes=processes)  # Num of CPUs

pool.map(normalize_image, test_data["image_dir"].values, chunksize = 8)
pool.map(normalize_image, train_data["image_dir"].values, chunksize = 8)
pool.map(normalize_image, val_data["image_dir"].values, chunksize = 8)

pool.close()
pool.terminate()


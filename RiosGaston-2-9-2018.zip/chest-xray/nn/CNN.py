
# coding: utf-8

# In[1]:


import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import tensorflow as tf
import os, random, time


# In[ ]:


# Hyperparameters

batch_size = 64
learning_rate = 0.01
training_epochs = 40
display_step = 10
alpha = 0.5

# To prevent overfitting
dropout = 0.75

summaries_dir = "./logs"


# In[ ]:


# Dataset and iterator creation

in_dir = "../input/preprocessed-normalized/"
test_normal_dir = in_dir + "test/NORMAL"
test_pneumonia_dir = in_dir + "test/PNEUMONIA"
train_normal_dir = in_dir + "train/NORMAL"
train_pneumonia_dir = in_dir + "train/PNEUMONIA"

full_url = np.vectorize(lambda url,prev_url: prev_url+"/"+url)
test_normal_data = pd.DataFrame(full_url(np.array(os.listdir(test_normal_dir)),test_normal_dir), columns=["image_dir"])
test_pneumonia_data = pd.DataFrame(full_url(np.array(os.listdir(test_pneumonia_dir)),test_pneumonia_dir), columns=["image_dir"])
train_normal_data = pd.DataFrame(full_url(np.array(os.listdir(train_normal_dir)),train_normal_dir), columns=["image_dir"])
train_pneumonia_data = pd.DataFrame(full_url(np.array(os.listdir(train_pneumonia_dir)),train_pneumonia_dir), columns=["image_dir"])

test_normal_data["class"] = "NORMAL"
test_pneumonia_data["class"] = "PNEUNOMIA"
train_normal_data["class"] = "NORMAL"
train_pneumonia_data["class"] = "PNEUNOMIA"

test_data = test_normal_data.append(test_pneumonia_data)
train_data = train_normal_data.append(train_pneumonia_data)

shape_sum = test_data.shape[0]+train_data.shape[0]

class_weight = tf.constant([
    (test_normal_data.shape[0]+train_normal_data.shape[0])/shape_sum,
    (test_pneumonia_data.shape[0]+train_pneumonia_data.shape[0])/shape_sum]) 

# Total ammount of landmarks
n_classes = 2

with tf.device('/cpu:0'):

    # Reads an image from a file, decodes it into a dense tensor, and resizes it
    # to a fixed shape.
    def _parse_function(filename, label):
        image_string = tf.read_file(filename)
        image_decoded = tf.image.decode_jpeg(image_string)
        image_decoded = tf.cast(image_decoded, tf.float32)
        image_decoded.set_shape((256, 256, 1))
        return image_decoded, label

    train_data = tf.data.Dataset.from_tensor_slices(
        (train_data["image_dir"].values, 
         pd.get_dummies(train_data["class"]).values))
    train_data = train_data.shuffle(buffer_size=10000)

    # for a small batch size
    train_data = train_data.map(_parse_function, num_parallel_calls=4)
    train_data = train_data.batch(batch_size)

    # for a large batch size (hundreds or thousands)
    # dataset = dataset.apply(tf.contrib.data.map_and_batch(
    #    map_func=_parse_function, batch_size=batch_size))

    # with gpu usage
    train_data = train_data.prefetch(1)
    
    test_data = tf.data.Dataset.from_tensor_slices(
        (test_data["image_dir"].values, 
         pd.get_dummies(test_data["class"]).values))
    test_data = test_data.map(_parse_function, num_parallel_calls=4)
    test_data = test_data.batch(batch_size)
    test_data = test_data.prefetch(1)
    
    iterator = tf.data.Iterator.from_structure(train_data.output_types, 
                                               train_data.output_shapes)
    x, y = iterator.get_next()

    train_init = iterator.make_initializer(train_data) # Inicializador para train_data
    test_init = iterator.make_initializer(test_data) # Inicializador para test_data
    
    # Visualize input x
    tf.summary.image("input", x, batch_size)


# In[ ]:


with tf.device('/device:GPU:0'):
    def conv2d(img, w, b):
        return tf.nn.leaky_relu(tf.nn.bias_add            (tf.nn.conv2d(img, w,            strides=[1, 1, 1, 1],            padding='SAME'),b), alpha=alpha)

    def max_pool(img, k):
        return tf.nn.max_pool(img,             ksize=[1, k, k, 1],            strides=[1, k, k, 1],            padding='SAME')

    wc1 = tf.Variable(tf.random_normal([3, 3, 1, 16]), name="wc1")
    bc1 = tf.Variable(tf.random_normal([16]), name="bc1")
    wc2 = tf.Variable(tf.random_normal([3, 3, 16, 32]), name="wc2")
    bc2 = tf.Variable(tf.random_normal([32]), name="bc2")
    # pool 128x128
    wc3 = tf.Variable(tf.random_normal([1, 1, 32, 64]), name="wc3")
    bc3 = tf.Variable(tf.random_normal([64]), name="bc3")
    # pool 64x64
    wc4 = tf.Variable(tf.random_normal([1, 1, 64, 128]), name="wc4")
    bc4 = tf.Variable(tf.random_normal([128]), name="bc4")
    # pool 32x32
    wd1 = tf.Variable(tf.random_normal([32*32*128, 512]), name="wd1")
    bd1 = tf.Variable(tf.random_normal([512]), name="bd1")
    wd2 = tf.Variable(tf.random_normal([512, 1024]), name="wd2")
    bd2 = tf.Variable(tf.random_normal([1024]), name="bd2")
    wout = tf.Variable(tf.random_normal([1024, n_classes]), name="wout")
    bout = tf.Variable(tf.random_normal([n_classes]), name="bout")

    # conv layer
    conv1 = conv2d(x,wc1,bc1)

    # conv layer
    conv2 = conv2d(conv1,wc2,bc2)

    # Max Pooling (down-sampling), this chooses the max value from a 2*2 matrix window and outputs a 64*64 matrix.
    conv2 = max_pool(conv2, k=2)
    # conv2 = avg_pool(conv2, k=2)

    # dropout to reduce overfitting
    keep_prob = tf. placeholder(tf.float32)
    conv2 = tf.nn.dropout(conv2, keep_prob)

    # conv layer
    conv3= conv2d(conv2,wc3,bc3)

    # Max Pooling (down-sampling), this chooses the max value from a 2*2 matrix window and outputs a 64*64 matrix.
    conv3 = max_pool(conv3, k=2)
    # conv2 = avg_pool(conv2, k=2)

    # dropout to reduce overfitting
    conv3 = tf.nn.dropout(conv3, keep_prob)

    # conv layer
    conv4 = conv2d(conv3,wc4,bc4)

    # Max Pooling (down-sampling), this chooses the max value from a 2*2 matrix window and outputs a 64*64 matrix.
    conv4 = max_pool(conv4, k=2)
    # conv2 = avg_pool(conv2, k=2)

    # dropout to reduce overfitting
    conv4 = tf.nn.dropout(conv4, keep_prob)

    # fc 1
    dense1 = tf.reshape(conv4, [-1, wd1.get_shape().as_list()[0]])
    dense1 = tf.nn.leaky_relu(tf.add(tf.matmul(dense1, wd1),bd1), alpha=alpha)
    dense1 = tf.nn.dropout(dense1, keep_prob)

    # fc 2
    dense2 = tf.reshape(dense1, [-1, wd2.get_shape().as_list()[0]])
    dense2 = tf.nn.leaky_relu(tf.add(tf.matmul(dense2, wd2),bd2), alpha=alpha)
    dense2 = tf.nn.dropout(dense2, keep_prob)

    # prediction
    pred = tf.add(tf.matmul(dense2, wout), bout)
    weighted_pred = tf.multiply(pred, class_weight)

    with tf.name_scope("cross_entropy"):
        # softmax
        cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(logits=weighted_pred, labels=y))
        tf.summary.scalar("cross_entropy", cost)

    # Optimizer
    optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(cost)

    with tf.name_scope("accuracy"):
        # Accuracy
        correct_pred = tf.equal(tf.argmax(pred,1), tf.argmax(y,1))
        accuracy = tf.reduce_mean(tf.cast(correct_pred, tf.float32))
        tf.summary.scalar("accuracy", accuracy)    

with tf.device('/cpu:0'):
    # Get all summary
    summ = tf.summary.merge_all()
    init = tf.global_variables_initializer()
    config = tf.ConfigProto(allow_soft_placement = True)


# In[ ]:


# Session start
with tf.Session(config=config) as sess:    
    run_options = tf.RunOptions(trace_level=tf.RunOptions.FULL_TRACE)
    run_metadata = tf.RunMetadata()
    train_writer = tf.summary.FileWriter(summaries_dir + '/train', sess.graph)
    test_writer = tf.summary.FileWriter(summaries_dir + '/test', sess.graph)
    
    # Required to get the filename matching to run.
    sess.run(init)
    
    total_epoch_time = 0
    step = 1
    # Compute epochs.
    for i in range(training_epochs):
        print("epoch: {}\n".format(i))
        print("\n")
        epoch_start = time.time()
        sess.run(train_init)
        epoch_step = 0
        avg_acc = 0
        avg_loss = 0
        try:
            while True:
                _, acc, loss, summary_str = sess.run([optimizer, accuracy, cost, summ], feed_dict={keep_prob: dropout}, options=run_options,run_metadata = run_metadata) 

                train_writer.add_summary(summary_str, step)

                if step % display_step == 0:
                    train_writer.add_run_metadata(run_metadata,"step {}".format(step))
                    print("step: {}".format(step))
                    print("accuracy: {}".format(acc))
                    print("loss: {}".format(loss))
                    print("\n")
                avg_acc += acc
                avg_loss += loss
                step += 1
                epoch_step += 1
        except tf.errors.OutOfRangeError:
            epoch_time = time.time() - epoch_start
            total_epoch_time += epoch_time
            print("epoch finished in {} seconds".format(epoch_time))
            print("Average epoch accuracy is {:.2f}%".format((avg_acc / epoch_step) * 100))
            print("Average epoch loss is {:.2f}".format(avg_loss / epoch_step))

            # Test            

            print("Test\n")
            sess.run(test_init)
            avg_acc = 0
            avg_loss = 0
            test_step=0
            try:
                while True:
                    acc, loss, summary_str = sess.run([accuracy, cost, summ], feed_dict={keep_prob: 1.})
                    avg_acc += acc
                    avg_loss += loss
                    test_step += 1

                    test_writer.add_summary(summary_str, test_step)
                    
                    print("accuracy: {}".format(acc))
                    print("loss: {}".format(loss))
                    print("\n")
            except tf.errors.OutOfRangeError:
                print("Average test set accuracy over {} iterations is {:.2f}%".format(test_step,(avg_acc / test_step) * 100))
                print("Average test set loss over {} iterations is {:.2f}".format(test_step,(avg_loss / test_step)))
                print("\n")

    print("Average epoch time: {} seconds".format(total_epoch_time/training_epochs))
    train_writer.add_run_metadata(run_metadata,"mySess")
    train_writer.close()
    test_writer.close()

